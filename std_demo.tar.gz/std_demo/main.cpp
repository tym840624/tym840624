#include <iostream>
#include <memory>
#include <unordered_map>
#include <vector>
#include <regex>
#include <functional>
#include <map>
#include <bitset>
#include <string>
#include <thread>
#include <queue>
#include <mutex>
#include <condition_variable> 

#include <unistd.h>
#include <stdio.h>
#include <sstream>
#include <string>

//#include <sys/eventfd.h>
#include "global.h"

enum DOOR_TYPE {
    LEFT = 0,
    RIGHT,
    TAIL
};

enum DOOR_STATE {
    OPEN,
    CLOSE
};

struct DoorInfo{
    DOOR_STATE    door_state;
    int order;
};

class CellData {
public:
    CellData(){
        std::cout << "CellData construction" << std::endl;
    }

    ~CellData(){
        std::cout << "CellData des construction" << std::endl;
    }
};

class Map{
public:
    Map(){
        std::cout << "Map construction" << std::endl;
    }

    ~Map(){
        if(_cell_data) {
            delete  []_cell_data;
            _cell_data = nullptr;
            std::cout << "Map cell is null" << std::endl;
        }
        std::cout << "Map des construction" << std::endl;
    }

    void init(){
        _cell_data = new CellData[12];
        std::cout << "init" << std::endl;
    }
private:
    CellData* _cell_data;
};

class DoorViewMgr {
public:
    DoorViewMgr():_current_order(1) {};
    virtual ~DoorViewMgr() {};

    void get_view(DOOR_TYPE& view_type) {
        int max_order = 0;
        for(auto it = _door_info.begin(); it != _door_info.end();++it) {
            if(it->second.door_state == DOOR_STATE::CLOSE) {
                //std::cout << "door " <<  it->first << "is closed" <<std::endl;
                continue;
            }
            
            if(max_order < it->second.order) {
                //std::cout << "it->second.order= " << it->second.order << std::endl;
                max_order = it->second.order;
                view_type = it->first;
            }
        }
    }

    void set_door_staus(DOOR_TYPE door_type,DOOR_STATE door_state) {
        if(_door_info.find(door_type) == _door_info.end()) {
            DoorInfo door_info;
            if(door_state == DOOR_STATE::OPEN) {
                _current_order++;
                door_info.order = _current_order;
            }
            else{
                door_info.order = 0;
            }
            
            door_info.door_state = door_state;
            _door_info.insert(std::make_pair(door_type,door_info));
        }
        else {
            if(door_state == DOOR_STATE::OPEN) {
                _current_order++;
                _door_info.at(door_type).order = _current_order;
            }
            else{
                _door_info.at(door_type).order = 0;
            }
            _door_info.at(door_type).door_state = door_state;
        }
    }

    int do_nothing();

    int get_door_cnt() {
        do_nothing();
        return _door_info.size();
    }

private:
    std::unordered_map<DOOR_TYPE,DoorInfo> _door_info;
    unsigned char _current_order;
};


void demo_unmap() {
    std::unordered_map<int,std::string> ki_map{
        {1,"Cat"},
        {2,"Dog"},
        {3,"Pig"}
    };

    for(const auto it:ki_map ) {
        std::cout << it.first << " = " << it.second << std::endl;
    }
}

void example_unmap() {
    std::unordered_map<std::string,std::vector<std::string>> _libs;
    _libs["dpc"].emplace_back("/usr/local/lib1");
    _libs["dpc"].emplace_back("/usr/local/lib2");
    _libs["dpc"].emplace_back("/usr/local/lib3");

    for(auto &&libs : _libs) {
        for(auto &&lib : libs.second){
            std::cout << lib << std::endl;
        }

    }
}

void example_lambda() {
    auto lambda = [](int a){
        std::cout << "lambda a = " << a << std::endl; 
    };
    std::function<void(int a)> func = std::bind(lambda,1);
    func(1);
}

struct st_order {
    int no;
};

using order = st_order;

void example_sort() {
    std::vector<order> orders;
    for(int i = 1; i <= 10; i++) {
        order tmp;
        tmp.no = i;
        orders.emplace_back(tmp);
    }

    std::sort(orders.begin(),orders.end(),[](order& f1,order& f2){
            return f1.no > f2.no;
        });
    
    for(auto it = orders.begin(); it != orders.end();++it) {
        std::cout << it->no << std::endl;
    }
}

void example_string() {
    std::string def("default_dispatcher_cfg");
    if(def.find("default") != std::string::npos){
        std::cout << "find" << std::endl;
    }
    else{
        std::cout << "can not find" << std::endl;
    }
    return ;
}

std::string hello("hello world!");
const std::string& get_hello() {
    //std::string hello("hello world!");
    return hello;
}

void example_regex() {
    std::string str1("GWM");
    std::string str2("Hello");
    bool status = regex_match(str1,std::regex("GWM.*"));
    std::cout << status << std::endl;
}

char* strcpy_safe(const char* _src, char* _dst, int _dst_buf_size) {
    if(_src == nullptr || _dst_buf_size <= 0 ) {
        return nullptr;
    }
    int i = 0;
    // while(*_src != '\0') {
    //     std::cout << *_src << std::endl;
    //     //_dst[i] = *_src;
    //     *(_dst+i) = *_src;
    //     i++;
    //     _src++;
    //     if(i > _dst_buf_size){
    //         break;
    //     }
    // }
    // std::cout << i << std::endl;
    char * p = _dst;
    while(i < _dst_buf_size -1 && *_src != '\0') {
        *p = *_src;
        p++;
        _src++;
        i++;
    }
    *p = '\0';
    return _dst;
}

struct ListNode {
    int id;
    ListNode *next;
};

ListNode* create_list(ListNode* head,int length) {
    if(head != nullptr){
        std::cout << "head is not nullptr" << std::endl;
        return head;
    }
    head = new ListNode;
    head->id = 0;
    ListNode* woker_ptr = head;
    for(int i=1;i<length;i++){
        ListNode* tmp = new ListNode;
        if(tmp != nullptr){
            tmp->id = i;
            tmp->next = nullptr;
            woker_ptr->next = tmp;
            woker_ptr = tmp;
        }
    }
    return head;
}

ListNode* delete_backend_node(ListNode* head,int n) {
    if(head == nullptr){
        std::cout << "head is nullptr" << std::endl;
        return head;
    }
    std::cout << "n = " << n <<std::endl;
    ListNode* fast_ptr = head;
    ListNode* slow_ptr = head;

    int i = 0;
    bool head_flag = false;
    while(fast_ptr->next) {
        fast_ptr = fast_ptr->next;
        i++;
        std::cout << "i=" << i << std::endl;
        if(i >= n){
            if(!fast_ptr) {
                slow_ptr = slow_ptr->next;
                std::cout <<  "slow_ptr->id = "  << slow_ptr->id << std::endl;
            }
            else {
                head_flag = true;
            }
        }
    }

    if(head_flag){
        slow_ptr = head;
        head = head->next;
        delete slow_ptr;
        std::cout <<  "head_flag is ture" << std::endl;
    }
    else{
        slow_ptr->next = slow_ptr->next->next;
        delete slow_ptr->next;
    }

    ListNode* worker = head;
    for(int i = 0;  ; i++) {
        std::cout <<  "worker->id = "  << worker->id << std::endl;
        worker = worker->next;
        if(worker == nullptr) {
            break;
        }
    }
    return head;
}

class MathCal{
public:
    int add(int a, int b){ //非静态函数
        return a+b;
    }
};
typedef int (MathCal::*FuncCal)(int a, int b);

void set_flag(bool flag=false);
void set_flag(bool flag){
	std::cout << flag << std::endl;
	return;
}

std::map<std::string, int32_t> _media_sessions;
void erase_map() {
    for(int32_t i=0;i<10;i++) {
        std::string a= "session_" + std::to_string(i);
        _media_sessions.insert(std::make_pair(a,i));
    }
    std::cout << "init map end" << std::endl;
    for(auto it = _media_sessions.begin(); it != _media_sessions.end(); ++it){
        std::cout << "a = " << it->first << " " << it->second << std::endl;
    }
    std::cout << "bianli " << std::endl;
    for (auto it = _media_sessions.begin(); it != _media_sessions.end(); ++it) {
        if (it->second == 9) {
            _media_sessions.erase(it);
            break;
        }
    }
    std::cout << "after erase" << std::endl;
    for(auto it = _media_sessions.begin(); it != _media_sessions.end(); ++it){
        std::cout << "a = " << it->first << " " << it->second << std::endl;
    }
}

std::string& get_name(){
    std::string name = "xiaohong";
    return name;
}

void func_move(std::string name_){
    std::cout << "name = " << name_ << std::endl;
    return;
}

inline int int_parser(const std::string& s) {
    int result = 0;
    try {
        result = std::stoi(s);
    }
    catch (std::invalid_argument& ia){
		std::cout << "ERROR: invalid_argument!" << ia.what() << std::endl;
	}
	catch (std::out_of_range&){
		std::cout << "ERROR: out_of_range!" << std::endl;
	}
	catch (...) {
		std::cout << "ERROR: unknow!" << std::endl;
	}
    return result;
}

inline float float_parser(const std::string& s) {
    float result = 0;
    try {
        result = std::stof(s);
    }
    catch (std::invalid_argument& ia){
		std::cout << "ERROR: invalid_argument!" << ia.what() << std::endl;
	}
	catch (std::out_of_range&){
		std::cout << "ERROR: out_of_range!" << std::endl;
	}
	catch (...) {
		std::cout << "ERROR: unknow!" << std::endl;
	}
    return result;
}

inline const char* pchar_parser(const std::string& s){
    return s.c_str();
}

inline std::string string_parser(const std::string& s) {
    return s;
}

template <typename T>
using parser_func = std::function<T(const std::string& )>;

template <typename T>
inline std::vector<T> array_paraser(const std::string& s,parser_func<T>&&  base_parser_) {
    std::vector<T> data;
    std::string word;

    auto pos = s.find(':');
    if (pos == std::string::npos) {
        std::cout << "format should be 'num:item1,item2,item3', " << s;
        return data;
    }

    try {
        int length = std::stoi(s.substr(0, pos));
        if (length <= 0) {
            std::cout << "length should > 0, " << length;
            return data;
        }

        data.reserve(length);
        std::istringstream iss(s.substr(pos + 1));
        std::string word;
        while (std::getline(iss, word, ',')) {
            if (!word.empty()) {
                data.push_back((base_parser_(word)));
            }
        }
        if (static_cast<int>(data.size()) != length) {
            std::cout << "ArrayParser failed to parse '" << s << "', reason: length not match, expected "
                            << length << ", but " << data.size();
            return data;
        }
        return data;
    } catch (const std::invalid_argument& e) {
        std::cout <<  "invalid_argument [" << s << "], reason: " << e.what();
        return data;
    } catch (const std::out_of_range& e) {
        std::cout << "out_of_range [" << s << "], reason: " << e.what();
        return data;
    } catch (...) {
        std::cout <<  "Unknown error [" << s << "]";
        return data;
    }
}


class H264Cache {
public:
    H264Cache(const uint8_t* buf_,const uint32_t size_,const std::string& str_time) {
        _buff = new uint8_t[size_];
        memcpy(_buff,buf_,size_);
        _str_time = str_time;
    }

    ~H264Cache(){
        std::cout << "free H264Cache" << std::endl;
        if(!_buff){
            delete _buff;
            _buff = nullptr;
        }
    }
    uint8_t* GetBuf(){
        return _buff;
    }
    uint32_t GetBuffLen(){
        return _size_;
    }
    std::string GetStrTime(){
        return _str_time;
    }
private:
    uint32_t _size_{0};
    uint8_t* _buff{nullptr};

    std::string _str_time;
    
};

class TcpServer {
public:
    typedef std::function<void()> Functor;

    TcpServer() = default;

    ~TcpServer() {
        _thread_worker.join();
    }

    void run(Functor functor) {
        std::unique_lock<std::mutex> lock(_mutex);
        _functors.push_back(functor);
        printf("push_back functor addr = %08X\n", &functor);
        lock.unlock();
    }

    void loop() {
        std::vector<Functor> functors;
        std::unique_lock<std::mutex> lock(_mutex);
        std::swap(functors, _functors);
        lock.unlock();

        std::cout  << "_functors size = " << _functors.size() << ",functors = " << functors.size() << std::endl;
        for (auto functor : functors) {
            functor();
            printf("functor addr = %08X\n", &functor);
        }
    }

    void thread_loop() {
        std::unique_lock<std::mutex> lck(_thread_mutex);
        while(1) {
            auto i = 0;
            _cv.wait(lck);
             std::cout << "thread do work,times =" << i++ << std::endl;
            loop();
        }
    }

    void thread_run(){
		_thread_worker = std::thread(std::bind(&TcpServer::thread_loop,this));
	}

    void notify() {
        _cv.notify_all();
    }

protected:
    std::vector<Functor> _functors;
    std::mutex _mutex;
    std::mutex _thread_mutex;
    std::condition_variable _cv;
    std::thread _thread_worker;
};

class RtspServer {
public:
     void push_frame(const uint8_t * data, uint32_t size, const std::string& str_time) {
        
        auto h264_buf = std::make_shared<H264Cache>(data,size,str_time);
        _h264_queue.push(h264_buf);
        auto functor=[&, this]() {
            // std::cout << "buff[0] = " << this->_h264_queue.front()->GetBuf()[0]  << std::endl;
            // std::cout << "bufflen = " << this->_h264_queue.front()->GetBuffLen() << std::endl;
            // std::cout << "StrTime = " << this->_h264_queue.front()->GetStrTime() << std::endl;
            this->_h264_queue.pop();
        };
        tcp_server.run(functor);
     }
    TcpServer tcp_server;
    //tcp_server.run(std::move(functor));    
public:
    std::queue<std::shared_ptr<H264Cache>> _h264_queue;
};

int main(int ac,char** av) {
    //demo_unmap();
    //example_unmap();
    //example_lambda();
    //example_sort();
    //example_string();
    //const std::string hello = get_hello();
    //std::string& _hello = get_hello();
    //std::cout << get_hello() << std::endl;
    //example_regex();

    // std::string str = "Hello";
    // char dst[3];
    // strcpy_safe(str.c_str(),dst,sizeof(dst));
    // for(int i=0; i<sizeof(dst); i++) {
    //     std::cout <<std::hex << (int)dst[i] << std::endl;
    // }
    // erase_map();
    // std::cout << "Begin core" << std::endl;
    // double d_ab = 10.0;
    // std::cout << 100/d_ab << std::endl;
    // std::cout << "End   core" << std::endl;
    // ListNode* head = nullptr;
    // head = create_list(head,10);
    // head = delete_backend_node(head,2);

    // FuncCal func_cal = &MathCal::add;
    // MathCal* p_mathcal = new MathCal();
    // int ret1 = (p_mathcal->*func_cal)(1,2);

    // MathCal mathcal;
    // int ret2 = (mathcal.*func_cal)(3,4);
    // std::cout << ret1 << std::endl;
    // std::cout << ret2 << std::endl;
    // std::cout << "    " << std::endl;
    // set_flag();
    // set_flag(true);

    // Map map;
    // map.init();

    // printf("linux page size is %d bytes\n",getpagesize());
    // uint8_t flag = 0;
    // int num = 1;
    // for(num = 1;num<=4;num++){
    //     switch (num)
    //     {
    //     case 1:
    //         flag |= 0x1;
    //     case 2:
    //         flag |= 0x2;
    //     case 3:
    //         flag |= 0x4;
    //     case 4:
    //         flag |= 0x8;
    //         break;
        
    //     default:
    //         break;
    //     }
    // }
    // flag = 1;
    // flag <<= 2;
    // flag >>= 1;
    // std::cout << "hhhhhhh" << std::endl;
    // //std::cout << std::hex << flag << std::endl;
    // std::cout << (std::bitset<8>)flag << std::endl;
    // if(flag == 0xF){
    //     std::cout << "是平车位" << std::endl;
    // }

    // uint8_t cnt = 5;
    // for(auto i=0;i<10;i++){
    //     if(cnt >= 0){
    //         std::cout << "cnt = " << cnt << std::endl;
    //         cnt--;
    //     }
    // }

    //std::string name = "Xiaoming";
    //func_move(get_name());
    // std::cout << int_parser("") << std::endl;
    // std::cout << float_parser("123.23") << std::endl;
    // std::cout << pchar_parser("111") << std::endl;
    
    // std::vector<std::string> data = std::move(array_paraser<std::string>("4:hello,world,xiao,ming",std::move(string_parser)));
    // //std::vector<int> data = std::move(array_paraser<int>("4:1,2,3,4",std::move(int_parser)));
    // for(auto it = data.begin(); it != data.end(); ++it){
    //     std::cout << *it << std::endl;
    // }


    // std::queue<std::unique_ptr<uint8_t[]>>  h264_queue;
    // for(uint8_t i = 49;i < 100;i++) {
    //     auto p_h264 = std::make_unique<uint8_t[]>(100);
    //     p_h264[1] = i;
    //     h264_queue.push(std::move(p_h264));
    //     std::cout  << std::hex << i ;
    // }
    // std::cout << h264_queue.back().get()[1] << " size = " << h264_queue.size() <<   std::endl;
    // int i = 0;
    // while(h264_queue.size()){
    //     std::cout << h264_queue.front().get()[1]  << " size = " << h264_queue.size() <<   std::endl;
    //     h264_queue.pop();
    // }
    // getchar();
    RtspServer rtsp_server;
    rtsp_server.tcp_server.thread_run();

    uint8_t buf[1000]={'A','B','C','D','E','F','G','H','I','J'};
    std::string TimeStr("2020-01-12");

    while (1) {
        uint8_t i = 0;
        for(i=49;i<58;i++) {
            //std::cout << "create" << std::endl;
            memcpy(buf,&i,sizeof(uint8_t));
            rtsp_server.push_frame(buf,10,TimeStr);
        }
        rtsp_server.tcp_server.notify();
        getchar();
    }

    // uint8_t buf[1000]={'A','B','C','D','E','F','G','H','I','J'};
    // std::string TimeStr("2020-01-12");
    // std::queue<std::shared_ptr<H264Cache>>  h264_queue;

    // for(uint8_t i = 49;i < 100;i++) {
    //     memcpy(buf,&i,sizeof(uint8_t));
    //     auto p_h264 = std::make_shared<H264Cache>(buf,100,TimeStr);
    //     h264_queue.push(std::move(p_h264));
    // }
    // std::queue<std::shared_ptr<H264Cache>> tmp;
    // std::cout << "Before swap:" << std::endl;
    // h264_queue.swap(tmp);
    getchar();
    return 0;
}
